#include "pch.h"
#include "application.h"

int main() {
    Application app(1400, 700);
    app.Run();
    return EXIT_SUCCESS;
}
