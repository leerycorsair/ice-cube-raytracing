#include "pch.h"
#include "application.h"
#include "renderer.h"
#include "objects.h"
#include "model.h"

#define OBJECT_NAME(i) (("Object " + std::to_string(i)).c_str())
#define LIGHT_NAME(i)  (("Light " + std::to_string(i)).c_str())

Framebuffer::Framebuffer(int width, int height)
    : m_width(width), m_height(height), m_buffer(width * height * 3) {}

void Framebuffer::clear() {
    std::fill(m_buffer.begin(), m_buffer.end(), 0);
}

void Framebuffer::setPixel(int x, int y, const Vec3& color) {
    assert(x >= 0 && x < m_width);
    assert(y >= 0 && y < m_height);
    int index = (y * m_width + x) * 3;
    m_buffer[index]     = static_cast<uint8_t>(std::min(1.0f, color.x) * 255);
    m_buffer[index + 1] = static_cast<uint8_t>(std::min(1.0f, color.y) * 255);
    m_buffer[index + 2] = static_cast<uint8_t>(std::min(1.0f, color.z) * 255);
}

Application::Application(int width, int height)
    : m_framebuffer(width, height), m_rerender(false), m_depth(0) {
    if (glfwInit() != GLFW_TRUE)
        throw std::runtime_error("Cannot init GLFW");

    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_COMPAT_PROFILE);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_RESIZABLE, GLFW_FALSE);
    m_window = glfwCreateWindow(width, height, "Application", nullptr, nullptr);
    if (!m_window) {
        glfwTerminate();
        throw std::runtime_error("Cannot create window");
    }

    glfwMakeContextCurrent(m_window);
    glfwSwapInterval(1);

    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        glfwDestroyWindow(m_window);
        glfwTerminate();
        throw std::runtime_error("Cannot load OpenGL functions");
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGui::StyleColorsDark();
    ImGui_ImplGlfw_InitForOpenGL(m_window, true);
    ImGui_ImplOpenGL3_Init("#version 330");
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    Init();
}

Application::~Application() noexcept {
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(m_window);
    glfwTerminate();
}

void Application::Run() {
    while (!glfwWindowShouldClose(m_window)) {
        if (m_rerender) {
            m_framebuffer.clear();
            Render(&m_framebuffer, m_camera, m_scene, m_depth);
            m_rerender = false;
        }

        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
        glDrawPixels(m_framebuffer.width(), m_framebuffer.height(),
                     GL_RGB, GL_UNSIGNED_BYTE, m_framebuffer.data());

        ImGui_ImplOpenGL3_NewFrame();
        ImGui_ImplGlfw_NewFrame();
        ImGui::NewFrame();
        ImGuiUpdate();
        ImGui::Render();
        ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());

        glfwSwapBuffers(m_window);
        glfwPollEvents();
    }
}

void Application::Init() {
    float aspect = (float)m_framebuffer.width() / m_framebuffer.height();
    m_camera = Camera(Vec3(0, 4, -7), Vec3(0, 0, 0), 45.f, aspect);
    m_scene.addObject(std::make_shared<Cube>());
    m_scene.addLight(Vec3(0, 5, 0));

    // Test image
    srand(time(NULL));
    for (int i = 0; i < 5; i++) {
        float x = rand() % 2;
        float y = rand() % 2;
        float z = rand() % 2;
        float r = 0.3;
        m_scene.addObject(std::make_shared<Sphere>(Vec3(x, y, z), r));
        Material& material = m_scene.objectAt(i+1)->getMaterial();
        material.diffuse = Vec3(1, 1, 1);
        material.diffuseAlbedo = 0.4f;
        material.refractAlbedo = 1.0f;
        material.refractive = 1.01f;
        m_scene.objectAt(i+1)->getScale() *= -0.3f;
        m_scene.objectAt(i+1)->getScale() -= -0.1f * i;
    }

    m_depth = 3;
    m_rerender = true;
}

void Application::ImGuiUpdate() {
    ImGuiWindowFlags flags = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove |
                             ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoFocusOnAppearing;
    ImGui::SetNextWindowPos(ImVec2(0.0f, 0.0f), ImGuiCond_Always, ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(375, 0), ImGuiCond_Always);
    ImGui::Begin("Settings", nullptr, flags);
    ImGuiUpdateScene();
    ImGui::Separator();
    ImGuiUpdateObjects();
    ImGui::Separator();
    ImGuiUpdateLights();
    ImGui::End();
}

void Application::ImGuiUpdateScene() {
    static bool showPlane = false;
    if (ImGui::SliderInt("Depth", &m_depth, 0, 10)) m_rerender = true;
    if (ImGui::SliderFloat3("Camera position", &m_camera.eye().x, -10, 10)) {
        m_camera.update();
        m_rerender = true;
    }
    if (ImGui::SliderFloat3("Camera lookAt", &m_camera.lookAt().x, -10, 10)) {
        m_camera.update();
        m_rerender = true;
    }
    if (ImGui::SliderFloat("FoV", &m_camera.fov(), 1, 90)) {
        m_camera.update();
        m_rerender = true;
    }
    if (ImGui::SliderFloat("Ambient", &m_scene.getAmbient(), 0, 1)) m_rerender = true;
    if (ImGui::Checkbox("Show plane", &showPlane)) {
        m_scene.showPlane(showPlane);
        m_rerender = true;
    }
}

void Application::ImGuiUpdateObjects() {
    static int objectIdx  = 0;
    std::vector<Scene::ObjectRef>& objects = m_scene.objects();
    if (!objects.empty()) {
        if (ImGui::BeginCombo("Objects", OBJECT_NAME(objectIdx))) {
            for (int i = 0; i < objects.size(); i++) {
                bool selected = objectIdx == i;
                if (ImGui::Selectable(OBJECT_NAME(i), selected))
                    objectIdx = i;
            }
            ImGui::EndCombo();
        }

        Scene::ObjectRef object = m_scene.objectAt(objectIdx);
        Material& material = object->getMaterial();
        if (ImGui::SliderFloat3("Position", &object->getPosition().x, -10, 10)) {
            object->update();
            m_rerender = true;
        }
        if (ImGui::SliderFloat3("Rotation", &object->getRotation().x, -180, 180)) {
            object->update();
            m_rerender = true;
        }
        if (ImGui::SliderFloat("Scale", &object->getScale(), -10, 10)) {
            object->update();
            m_rerender = true;
        }
        if (ImGui::SliderFloat3("Diffuse", &material.diffuse.x, 0, 1)) m_rerender = true;
        if (ImGui::SliderFloat3("Specular", &material.specular.x, 0, 1)) m_rerender = true;
        if (ImGui::SliderFloat("Diffuse albedo", &material.diffuseAlbedo, 0, 1)) m_rerender = true;
        if (ImGui::SliderFloat("Specular albedo", &material.specularAlbedo, 0, 1)) m_rerender = true;
        if (ImGui::SliderFloat("Reflect albedo", &material.reflectAlbedo, 0, 1)) m_rerender = true;
        if (ImGui::SliderFloat("Refract albedo", &material.refractAlbedo, 0, 1)) m_rerender = true;
        if (ImGui::SliderFloat("Shininess", &material.shininess, 0, 1000)) m_rerender = true;
        if (ImGui::SliderFloat("Refractive", &material.refractive, 1, 5)) m_rerender = true;
        if (ImGui::Button("Remove object")) {
            objects.erase(objects.begin() + objectIdx);
            objectIdx = 0;
            m_rerender = true;
        }
        ImGui::SameLine();
    }
    if (ImGui::Button("Add Sphere")) {
        m_scene.addObject(std::make_shared<Sphere>());
        objectIdx = objects.size() - 1;
        m_rerender = true;
    }

    static char path[120] = {0};
    if (ImGui::Button("Add Wireframe")) {
        try {
            m_scene.addObject(std::make_shared<Model>(path));
            objectIdx = objects.size() - 1;
            m_rerender = true;
        } catch (const std::runtime_error& error) {
            ImGui::OpenPopup("OpenError");
        }
    }
    ImGui::SameLine();
    ImGui::InputText("", path, 120);

    ImVec2 center = ImGui::GetMainViewport()->GetCenter();
    ImGui::SetNextWindowPos(center, ImGuiCond_Appearing, ImVec2(0.5f, 0.5f));
    if (ImGui::BeginPopupModal("OpenError", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::Text("Cannot open file");
        ImGui::Separator();
        if (ImGui::Button("OK", ImVec2(120, 0)))
            ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

void Application::ImGuiUpdateLights() {
    static int lightIdx = 0;
    std::vector<Vec3>& lights = m_scene.lights();
    if (!lights.empty()) {
        if (ImGui::BeginCombo("Lights", LIGHT_NAME(lightIdx))) {
            for (int i = 0; i < lights.size(); i++) {
                bool selected = lightIdx == i;
                if (ImGui::Selectable(LIGHT_NAME(i), selected))
                    lightIdx = i;
            }
            ImGui::EndCombo();
        }

        Vec3& light = m_scene.lightAt(lightIdx);
        if (ImGui::SliderFloat3("Light Position", &light.x, -15, 15)) m_rerender = true;
        if (ImGui::Button("Remove source")) {
            lights.erase(lights.begin() + lightIdx);
            lightIdx = 0;
            m_rerender = true;
        }
        ImGui::SameLine();
    }
    if (ImGui::Button("Add source")) {
        lights.emplace_back(Vec3(0, 0, 0));
        lightIdx = lights.size() - 1;
        m_rerender = true;
    }
}